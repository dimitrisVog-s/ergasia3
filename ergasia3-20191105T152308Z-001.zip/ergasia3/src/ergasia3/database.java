package ergasia3;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.io.IOException;
import java.io.PrintWriter;
public class database{
	
	
	String query="Insert into user values(?,?,?,?,?)";
	String url="jdbc:mysql://localhost/data?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	String user="root";
	String pass="LedZeppelin1997";
	
	
	public boolean InsertMember(String id,String password,String name,String emailid,String country) {
		
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con= DriverManager.getConnection(url,user,pass);
			 PreparedStatement insert=con.prepareStatement(query);
			 
			 insert.setString(1,id);
			 insert.setString(2,password);
			 insert.setString(3,name);
			 insert.setString(4,emailid);
			 insert.setString(5,country);
			 insert.executeUpdate();
			  
			 
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		
		return false;
		
	}


	
}